const Footer = () => {
  return (
    <div className="bg-gray-800 text-center text-gray-400 p-4">
      <p>&copy; 2025 Eres Dashboard</p>
    </div>
  );
};

export default Footer;
